from flask import Flask, render_template, request, redirect, url_for, jsonify
import random
import string
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] ='sqlite:///url.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class URL(db.Model):
	sno = db.Column(db.Integer, primary_key=True)
	code = db.Column(db.String(80), unique=True, nullable=False)
	url_red = db.Column(db.String(200), nullable=False)
	
	def __repr__(self):
		return str(self.code)+","+str(self.url_red)
	
@app.route("/", methods=["GET", "POST"])
def shorten_url():
	if request.method=='POST':
		url = request.form["url"]
		code = "".join(random.sample(string.ascii_lowercase, 6))
		short_url = "https://short.url" + url_for("open_link", code=code)
		db.session.add(URL(code=code, url_red=url))
		db.session.commit()
		return render_template("index.html", short_url=short_url)
	return render_template("index.html", short_url=None)

@app.route("/<string:code>")
def open_link(code):
	red = URL.query.filter_by(code=code).first()
	try:
		red.url_red
	except:
		return "Url Not Valid"
	else:
		return redirect(red.url_red)
	
if __name__ == "__main__":
    app.run(debug=True)